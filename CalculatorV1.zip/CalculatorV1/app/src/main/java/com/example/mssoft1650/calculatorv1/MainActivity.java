package com.example.mssoft1650.calculatorv1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    int Firstvalue , Secondvalue;
    boolean addtion,subraction , mutilification , division;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btn1 = findViewById(R.id.b1);
        final Button btn2 = findViewById(R.id.b2);
        Button btn3 = findViewById(R.id.b3);
        Button btnadd = findViewById(R.id.badd);
        Button btnres = findViewById(R.id.result);
        final EditText op = findViewById(R.id.display);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                op.setText(op.getText()+"1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                op.setText(op.getText()+"2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                op.setText(op.getText()+"3");
            }
        });

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Firstvalue=Integer.parseInt(op.getText()+"");
                addtion=true;
                //op.setText(null);
            }
        });

        btnres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Secondvalue=Integer.parseInt(op.getText()+"");
                if (addtion==true)
                {
                    op.setText(Firstvalue + Secondvalue + "");
                    addtion=false;
                }
                if(subraction==true)
                {
                    op.setText(Firstvalue - Secondvalue + "");
                    subraction=false;
                }
                if(mutilification==true)
                {
                    op.setText(Firstvalue * Secondvalue + "");
                    mutilification=false;
                }
                if(division==true)
                {
                    op.setText(Firstvalue / Secondvalue + "");
                    division=false;
                }
            }

        });
    }
}
