package com.skybersoft.www.jptcleaningservices;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class index extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent mainactivity = new Intent(index.this,MainActivity.class);
                startActivity(mainactivity);
                finish();
            }
        },2000);
    }
}
