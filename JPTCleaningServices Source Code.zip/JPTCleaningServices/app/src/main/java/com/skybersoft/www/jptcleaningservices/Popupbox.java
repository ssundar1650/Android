package com.skybersoft.www.jptcleaningservices;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.skybersoft.www.jptcleaningservices.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.acl.LastOwnerException;
import java.util.HashMap;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;


public class Popupbox extends AppCompatDialogFragment {
    EditText name;
    EditText email;
    EditText phone;
    EditText date;
    private Spinner selectservice;
    Button order;
    String services = "";
    int result = 0;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String url = "http://creator.skybercorp.com/jptmail.php";
    ProgressDialog mydialog;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.popupbox,null);

        name = view.findViewById(R.id.name);
        email = view.findViewById(R.id.email);
        phone = view.findViewById(R.id.phone);
        date = view.findViewById(R.id.date);
        order = view.findViewById(R.id.order);
        selectservice = view.findViewById(R.id.selectservice);
        mydialog = new ProgressDialog(getActivity(),R.style.MyAlertDialogStyle);
        mydialog.setMessage("Please Wait");
        mydialog.setCanceledOnTouchOutside(false);
        mydialog.setCancelable(false);




        selectservice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position)
                {
                    case 1:
                        services = "Home Cleaning Services";
                        break;
                    case 2:
                        services = "Bathroom / Restroom Cleaning Services";
                        break;
                    case 3:
                        services = "Sofa Cleaning Services";
                        break;
                    case 4:
                        services = "Kitchen Room Cleaning Services";
                        break;
                    case 5:
                        services = "Carpet Cleaning Services";
                        break;
                    case 6:
                        services = "Paining / Work / Services";
                        break;
                    case 7:
                        services = "Floor Cleaning Services";
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        builder.setView(view);
        builder.setCancelable(false);


//                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        Intent sucess = new Intent(getActivity(),success.class);
//                        startActivity(sucess);
//                    }
//                })
//                .setPositiveButton("Submit", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                    }
//                });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                urlcal();
            }
        });
        builder.setCancelable(false);
        return builder.create();
    }
    public void urlcal(){
        mydialog.show();
        String gemail = email.getText().toString().trim();
        if(name.getText().length() > 3 && phone.getText().length() > 9 && services.length() > 0 && date.getText().length() > 0) {

            if(gemail.matches(emailPattern)) {

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONArray jsonArray = new JSONArray(response);
                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                            String code = jsonObject.getString("status");

                            if (code.equals("1")) {
                                mydialog.dismiss();
                                Intent intent = new Intent(getActivity(), success.class);
                                startActivity(intent);


                            } else {
                                Toast.makeText(getActivity(), code, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mydialog.dismiss();
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                            Toast.makeText(getContext(), "Check Your Internet Connection", Toast.LENGTH_SHORT).show();

                        } else if (error instanceof AuthFailureError) {
                            Toast.makeText(getContext(), "Authentication Error!", Toast.LENGTH_SHORT).show();
                        } else if (error instanceof ServerError) {
                            Toast.makeText(getContext(), "Server Side Error!", Toast.LENGTH_SHORT).show();
                        } else if (error instanceof NetworkError) {
                            Toast.makeText(getContext(), "Network Error!", Toast.LENGTH_SHORT).show();
                        } else if (error instanceof ParseError) {
                            Toast.makeText(getContext(), "Parse Error!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();

                        params.put("name", name.getText().toString());
                        params.put("email", email.getText().toString());
                        params.put("phone", phone.getText().toString());
                        params.put("service", services);
                        params.put("date", date.getText().toString());

                        return params;
                    }
                };
                MySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
            }
            else {
                mydialog.dismiss();
                Toast.makeText(getContext(),"Enter The Correct Email Address",Toast.LENGTH_LONG).show();
            }
        }
        else
        {
            mydialog.dismiss();
            Toast.makeText(getContext(),"Please Enter The Correct Details",Toast.LENGTH_LONG).show();
        }
    }

}
